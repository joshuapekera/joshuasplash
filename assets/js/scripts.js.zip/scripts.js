/*
  * (c) Joshua Pekera, joshuapekera.com
*/
(function( win ){
	var doc = win.document;
	
	// If there's a hash, or addEventListener is undefined, stop here
	if( !location.hash && win.addEventListener ){
		
		//scroll to 1
		window.scrollTo( 0, 1 );
		var scrollTop = 1,
			getScrollTop = function(){
				return win.pageYOffset || doc.compatMode === "CSS1Compat" && doc.documentElement.scrollTop || doc.body.scrollTop || 0;
			},
		
			//reset to 0 on bodyready, if needed
			bodycheck = setInterval(function(){
				if( doc.body ){
					clearInterval( bodycheck );
					scrollTop = getScrollTop();
					win.scrollTo( 0, scrollTop === 1 ? 0 : 1 );
				}
			}, 15 );
		
		win.addEventListener( "load", function(){
			setTimeout(function(){
				//at load, if user hasn't scrolled more than 20 or so...
				if( getScrollTop() < 20 ){
					//reset to hide addr bar at onload
					win.scrollTo( 0, scrollTop === 1 ? 0 : 1 );
				}
			}, 0);
		} );
	}
})( this );

/*
  * Viewport Slideout
  * (c) Joshua Pekera, joshuapekera.com
  * MIT License
*/
(function() {
    
    var body = document.body,
            trigger = document.querySelectorAll('#page .plus')[0],
            closeMask = document.getElementById('close-mask'),
            pageView = document.getElementById('page'),
            menuView = document.getElementById('menu');

    trigger.addEventListener('click', function() {
        if (hasClass(body, 'menu-open')) {
            hideMenu();
        } else {
            showMenu();
        }
    });

    closeMask.addEventListener('click', function(e) {
        e.preventDefault();
        hideMenu();
    });

    setTimeout(function() { window.scrollTo(0, 0); }, 100);

	function doOnOrientationChange() {
		switch(window.orientation) {
			case -90:
			case 90:
			pageView.removeAttribute('style', 'width');
			if (hasClass(body, 'menu-open')) {
				pageView.style.width = window.innerWidth - 40 + "px";
				pageView.style.width = window.innerHeight + "px";
			} else {
				pageView.style.width = window.innerWidth + "px";
				pageView.style.width = window.innerHeight + "px";
			}
			break;
			default:
			pageView.removeAttribute('style', 'width');
			break;
		}
	}
	window.onorientationchange = function() {
		doOnOrientationChange();
	};

    function showMenu() {
        // window.scrollTo(0, 0);
        body.setAttribute('class', 'menu-open');
        closeMask.style.display = 'block';
        menuView.style.display = 'block';
        pageView.style.width = window.innerWidth - 40 + "px";
        closeMask.style.width = window.innerWidth + "px";
        closeMask.style.height = window.outerHeight + "px";
        menuView.style.height = window.outerHeight + "px";
        
    }

    function hideMenu() {
        window.scrollTo(0, 0);
        body.removeAttribute('class');
        closeMask.style.display = 'none';
        closeMask.removeAttribute('style', 'width');
        closeMask.removeAttribute('style', 'height');
        pageView.removeAttribute('style', 'width');
    }

    function hasClass(el, selector) {
        var className = " " + selector + " ";
        return (el.nodeType === 1 && (" " + el.className + " ").replace(/[\n\t\r]/g, " ").indexOf(className) > -1);
    }
    
})();